class SSHHost {
  final String id;
  final String name;
  final String hostnameOrIp;
  final String username;
  final int port;
  final String? password;
  final String? keyFilePath;

  SSHHost({
    required this.id,
    required this.name,
    required this.hostnameOrIp,
    required this.username,
    required this.port,
    this.password,
    this.keyFilePath,
  });

  SSHHost copyWith({
    String? id,
    String? name,
    String? hostnameOrIp,
    String? username,
    int? port,
    String? password,
    String? keyFilePath,
  }) {
    return SSHHost(
      id: id ?? this.id,
      name: name ?? this.name,
      hostnameOrIp: hostnameOrIp ?? this.hostnameOrIp,
      username: username ?? this.username,
      port: port ?? this.port,
      password: password ?? this.password,
      keyFilePath: keyFilePath ?? this.keyFilePath,
    );
  }

  factory SSHHost.fromJson(Map<String, dynamic> json) {
    return SSHHost(
      id: json['id'],
      name: json['name'],
      hostnameOrIp: json['hostnameOrIp'],
      username: json['username'],
      port: json['port'],
      password: json['password'],
      keyFilePath: json['keyFilePath'],
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'hostnameOrIp': hostnameOrIp,
        'username': username,
        'port': port,
        'password': password,
        'keyFilePath': keyFilePath,
      };
}
