import 'package:flutter/material.dart';
import 'screens/terminal_tabs_page.dart';

void main() {
  runApp(const MaterialApp(
    home: TerminalTabsPage(),
    debugShowCheckedModeBanner: false,
  ));
}
