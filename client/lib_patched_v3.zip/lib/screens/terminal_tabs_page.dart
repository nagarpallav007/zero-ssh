import 'package:flutter/material.dart';
import '../models/ssh_host.dart';
import 'terminal_page.dart';
import 'host_management_page.dart';

class TerminalTabsPage extends StatefulWidget {
  const TerminalTabsPage({super.key});

  @override
  State<TerminalTabsPage> createState() => _TerminalTabsPageState();
}

class _TerminalTabsPageState extends State<TerminalTabsPage> {
  late List<_TabData> tabs;
  int currentIndex = 0;
  late PageController _pageController;

  @override
  void initState() {
    super.initState();
    tabs = [
      _TabData.hostsTab(),
    ];
    _pageController = PageController();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _onTabSwitch(int i) {
    setState(() => currentIndex = i);
    _pageController.animateToPage(
      i,
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeInOut,
    );
  }

  void _onTabClose(int i) {
    if (tabs.length == 1) return;
    setState(() {
      tabs.removeAt(i);
      if (currentIndex >= tabs.length) {
        currentIndex = tabs.length - 1;
      }
    });
    
    // Update page controller to match new current index
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_pageController.hasClients) {
        _pageController.animateToPage(
          currentIndex,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  void _onNewTab() {
    setState(() {
      tabs.add(_TabData.hostsTab());
      currentIndex = tabs.length - 1;
    });
    
    // Navigate to the new tab
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _pageController.animateToPage(
        currentIndex,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
      );
    });
  }

  void _openSessionTab(SSHHost host) {
    final existing = tabs.indexWhere((tab) =>
        tab.isSession && tab.host != null && tab.host!.id == host.id);
    if (existing != -1) {
      _onTabSwitch(existing);
    } else {
      setState(() {
        tabs.add(_TabData.sessionTab(host));
        currentIndex = tabs.length - 1;
      });
      
      // Navigate to the new session tab
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _pageController.animateToPage(
          currentIndex,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeInOut,
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final tabBgColor = const Color(0xFF1A1C24);
    final activeTabColor = const Color(0xFF1DD366);

    return Scaffold(
      backgroundColor: const Color(0xFF151722),
      body: Column(
        children: [
          // Tab Bar always on top
          Container(
            color: tabBgColor,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Row(
              children: [
                ...List.generate(tabs.length, (i) {
                  final tab = tabs[i];
                  final selected = i == currentIndex;
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    decoration: BoxDecoration(
                      color: selected ? activeTabColor : tabBgColor,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () => _onTabSwitch(i),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                            child: Text(
                              tab.title,
                              style: TextStyle(
                                color: selected ? Colors.black : Colors.white70,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () => _onTabClose(i),
                          child: Padding(
                            padding: const EdgeInsets.only(right: 8.0),
                            child: Icon(Icons.close, size: 16, color: selected ? Colors.black54 : Colors.white54),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
                // "New Tab" button
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  child: OutlinedButton.icon(
                    onPressed: _onNewTab,
                    icon: const Icon(Icons.add, size: 16, color: Colors.white70),
                    label: const Text(
                      "New Tab",
                      style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w500),
                    ),
                    style: OutlinedButton.styleFrom(
                      backgroundColor: tabBgColor,
                      side: const BorderSide(color: Colors.white10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: PageView.builder(
              controller: _pageController,
              itemCount: tabs.length,
              onPageChanged: (index) {
                setState(() => currentIndex = index);
              },
              itemBuilder: (context, index) {
                final tab = tabs[index];
                return tab.isHosts
                    ? HostManagementPage(
                        onHostOpen: _openSessionTab,
                      )
                    : TerminalPage(host: tab.host!);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _TabData {
  final String title;
  final SSHHost? host;
  final bool isHosts;
  final bool isSession;

  _TabData({required this.title, this.host, required this.isHosts, required this.isSession});

  static _TabData hostsTab() => _TabData(title: "SSH Hosts", isHosts: true, isSession: false);
  static _TabData sessionTab(SSHHost host) =>
      _TabData(title: host.name, host: host, isHosts: false, isSession: true);
}