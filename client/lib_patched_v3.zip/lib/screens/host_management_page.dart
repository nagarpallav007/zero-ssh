import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:uuid/uuid.dart';

import '../models/ssh_host.dart';
import '../services/storage_service.dart';
import 'terminal_tabs_page.dart';

class HostManagementPage extends StatefulWidget {
  final bool pickMode;
  final void Function(SSHHost)? onHostOpen;

  const HostManagementPage({super.key, this.pickMode = false, this.onHostOpen});

  @override
  State<HostManagementPage> createState() => _HostManagementPageState();
}

class _HostManagementPageState extends State<HostManagementPage> {
  List<SSHHost> _hosts = [];
  final _storage = StorageService();

  @override
  void initState() {
    super.initState();
    _loadHosts();
  }

  Future<void> _loadHosts() async {
    try {
      final loaded = await _storage.loadHosts();
      
      // IMPORTANT: Check if widget is still mounted before calling setState
      if (mounted) {
        setState(() => _hosts = loaded);
      }
    } catch (e) {
      // Handle any errors that might occur during loading
      if (mounted) {
        // You could show an error message or handle the error state here
        print('Error loading hosts: $e');
      }
    }
  }

  Future<void> _saveHosts() async {
    try {
      await _storage.saveHosts(_hosts);
    } catch (e) {
      // Handle save errors
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving hosts: $e')),
        );
      }
    }
  }

  void _addOrEditHost({SSHHost? existing}) {
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final hostCtrl = TextEditingController(text: existing?.hostnameOrIp ?? '');
    final userCtrl = TextEditingController(text: existing?.username ?? '');
    final portCtrl = TextEditingController(text: existing?.port.toString() ?? '22');
    final passwordCtrl = TextEditingController(text: existing?.password ?? '');
    final keyFileCtrl = TextEditingController(text: existing?.keyFilePath ?? '');

    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setStateDialog) => AlertDialog(
          title: Text(existing == null ? 'Add Host' : 'Edit Host'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(labelText: 'Name'),
                ),
                TextField(
                  controller: hostCtrl,
                  decoration: const InputDecoration(labelText: 'Hostname / IP address'),
                ),
                TextField(
                  controller: userCtrl,
                  decoration: const InputDecoration(labelText: 'Username'),
                ),
                TextField(
                  controller: portCtrl,
                  decoration: const InputDecoration(labelText: 'Port'),
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                ),
                TextField(
                  controller: passwordCtrl,
                  decoration: const InputDecoration(labelText: 'Password (optional)'),
                  obscureText: true,
                ),
                Row(
                  children: [
                    // Key File Path TextField (readonly, filled from picker)
                    Expanded(
                      child: TextField(
                        controller: keyFileCtrl,
                        decoration: const InputDecoration(labelText: 'Key File Path (optional)'),
                        readOnly: true,
                      ),
                    ),
                    IconButton(
                      tooltip: 'Pick Key File',
                      icon: const Icon(Icons.folder_open),
                      onPressed: () async {
                        try {
                          final result = await FilePicker.platform.pickFiles(type: FileType.any);
                          if (result != null && result.files.single.path != null) {
                            setStateDialog(() {
                              keyFileCtrl.text = result.files.single.path!;
                            });
                          }
                        } catch (e) {
                          // Handle file picker errors
                          print('File picker error: $e');
                        }
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (hostCtrl.text.trim().isEmpty ||
                    userCtrl.text.trim().isEmpty ||
                    nameCtrl.text.trim().isEmpty) {
                  // Simple validation: name, host, and username required
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Name, Hostname/IP, and Username are required.")),
                  );
                  return;
                }

                final newHost = SSHHost(
                  id: existing?.id ?? const Uuid().v4(),
                  name: nameCtrl.text.trim(),
                  hostnameOrIp: hostCtrl.text.trim(),
                  username: userCtrl.text.trim(),
                  port: int.tryParse(portCtrl.text.trim()) ?? 22,
                  password: passwordCtrl.text.isNotEmpty ? passwordCtrl.text : null,
                  keyFilePath: keyFileCtrl.text.isNotEmpty ? keyFileCtrl.text : null,
                );

                // Check mounted before setState
                if (mounted) {
                  setState(() {
                    if (existing != null) {
                      final index = _hosts.indexWhere((h) => h.id == existing.id);
                      _hosts[index] = newHost;
                    } else {
                      _hosts.add(newHost);
                    }
                  });
                  
                  // Save hosts asynchronously but don't wait for it
                  _saveHosts();
                }
                
                Navigator.pop(context);
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  void _deleteHost(String id) {
    if (mounted) {
      setState(() => _hosts.removeWhere((h) => h.id == id));
      _saveHosts();
    }
  }

  void _openTerminalTabs(SSHHost host) {
    if (widget.onHostOpen != null) {
      widget.onHostOpen!(host);
    } else if (widget.pickMode) {
      Navigator.pop(context, host);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SSH Hosts')),
      body: _hosts.isEmpty
          ? const Center(child: Text("No hosts yet. Add one!"))
          : ListView.builder(
              itemCount: _hosts.length,
              itemBuilder: (context, index) {
                final host = _hosts[index];
                return ListTile(
                  title: Text(host.name),
                  subtitle: Text('${host.username}@${host.hostnameOrIp}:${host.port}'),
                  trailing: PopupMenuButton<String>(
                    onSelected: (value) {
                      if (value == 'edit') {
                        _addOrEditHost(existing: host);
                      } else if (value == 'delete') {
                        _deleteHost(host.id);
                      }
                    },
                    itemBuilder: (ctx) => [
                      const PopupMenuItem(value: 'edit', child: Text('Edit')),
                      const PopupMenuItem(value: 'delete', child: Text('Delete')),
                    ],
                  ),
                  onTap: () => _openTerminalTabs(host),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addOrEditHost(),
        child: const Icon(Icons.add),
      ),
    );
  }

  @override
  void dispose() {
    // Clean up any resources if needed
    super.dispose();
  }
}