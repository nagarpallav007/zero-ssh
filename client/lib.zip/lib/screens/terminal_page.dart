import 'dart:typed_data';
import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:dartssh2/dartssh2.dart';
import '../models/ssh_host.dart';

class TerminalPage extends StatefulWidget {
  final SSHHost host;

  const TerminalPage({super.key, required this.host});

  @override
  State<TerminalPage> createState() => _TerminalPageState();
}

class _TerminalPageState extends State<TerminalPage> 
    with AutomaticKeepAliveClientMixin<TerminalPage> {
  
  @override
  bool get wantKeepAlive => true;

  SSHClient? client;
  SSHSession? shellSession;
  bool connecting = true;
  String? errorMessage;
  final List<String> _outputLines = [];
  final TextEditingController _inputController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _inputFocus = FocusNode();
  late SSHHost currentHost;
  String _currentLine = '';
  List<String> _commandHistory = [];
  int _historyIndex = -1;

  @override
  void initState() {
    super.initState();
    currentHost = widget.host;
    _connectSSH(currentHost);
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _inputFocus.requestFocus();
    });
  }

  void _addOutput(String text) {
    if (!mounted) return;
    
    final lines = text.split('\n');
    
    setState(() {
      for (int i = 0; i < lines.length; i++) {
        if (i == 0 && _currentLine.isNotEmpty) {
          _currentLine += lines[i];
        } else {
          if (_currentLine.isNotEmpty) {
            _outputLines.add(_currentLine);
            _currentLine = '';
          }
          if (lines[i].isNotEmpty || i == lines.length - 1) {
            _currentLine = lines[i];
          }
        }
      }
      
      if (text.endsWith('\n') && _currentLine.isNotEmpty) {
        _outputLines.add(_currentLine);
        _currentLine = '';
      }
      
      if (_outputLines.length > 1000) {
        _outputLines.removeRange(0, _outputLines.length - 1000);
      }
    });
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 100),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _connectSSH(SSHHost host) async {
    if (!mounted) return;
    
    setState(() {
      connecting = true;
      errorMessage = null;
      _outputLines.clear();
      _currentLine = '';
    });
    
    _addOutput('Connecting to ${host.username}@${host.hostnameOrIp}:${host.port}...\n');
    
    try {
      _addOutput('Testing connectivity...\n');
      final basicSocket = await Socket.connect(
        host.hostnameOrIp, 
        host.port,
        timeout: const Duration(seconds: 10),
      ).timeout(const Duration(seconds: 15));
      await basicSocket.close();
      _addOutput('✓ Connection successful\n');
      
      _addOutput('Establishing SSH session...\n');
      final sshSocket = await SSHSocket.connect(
        host.hostnameOrIp,
        host.port,
        timeout: const Duration(seconds: 15),
      ).timeout(const Duration(seconds: 20));
      
      SSHClient sshClient;
      
      if (host.keyFilePath != null && host.keyFilePath!.isNotEmpty) {
        _addOutput('Authenticating with private key...\n');
        final keyFile = File(host.keyFilePath!);
        if (!await keyFile.exists()) {
          if (mounted) {
            setState(() => errorMessage = "Private key file not found: ${host.keyFilePath}");
          }
          return;
        }
        
        try {
          final keyContent = await keyFile.readAsString();
          final keyPairs = SSHKeyPair.fromPem(keyContent);
          _addOutput('✓ Private key loaded\n');
          
          if (host.password != null && host.password!.isNotEmpty) {
            _addOutput('Using private key with passphrase...\n');
            sshClient = SSHClient(
              sshSocket,
              username: host.username,
              identities: keyPairs,
              onPasswordRequest: () => host.password!,
            );
          } else {
            sshClient = SSHClient(
              sshSocket,
              username: host.username,
              identities: keyPairs,
            );
          }
        } catch (e) {
          if (mounted) {
            setState(() => errorMessage = "Failed to load private key: $e");
          }
          return;
        }
      } else if (host.password != null && host.password!.isNotEmpty) {
        _addOutput('Authenticating with password...\n');
        sshClient = SSHClient(
          sshSocket,
          username: host.username,
          onPasswordRequest: () => host.password!,
        );
      } else {
        if (mounted) {
          setState(() => errorMessage = "No authentication method provided.");
        }
        return;
      }

      _addOutput('Starting shell...\n');
      final shell = await sshClient.shell(
        pty: const SSHPtyConfig(
          width: 120,
          height: 30,
          type: 'xterm-256color',
        ),
      ).timeout(const Duration(seconds: 30));
      
      client = sshClient;
      shellSession = shell;

      shell.stdout.listen(
        (data) {
          final text = String.fromCharCodes(data);
          _addOutput(text);
        },
        onError: (error) {
          _addOutput('\nShell output error: $error\n');
        },
      );
      
      shell.stderr.listen(
        (data) {
          final text = String.fromCharCodes(data);
          _addOutput(text);
        },
      );

      shell.done.then((_) {
        _addOutput('\n--- SSH session ended ---\n');
      }).catchError((error) {
        _addOutput('\n--- SSH session error: $error ---\n');
      });

      _addOutput('✓ Connected successfully!\n\n');
      
      if (mounted) {
        setState(() => connecting = false);
      }
      
    } on TimeoutException catch (e) {
      if (mounted) {
        setState(() {
          errorMessage = "Connection timeout. Server may be unreachable.";
          connecting = false;
        });
      }
    } on SocketException catch (e) {
      if (mounted) {
        setState(() {
          errorMessage = "Network error: ${e.message}";
          connecting = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          errorMessage = "Connection error: $e";
          connecting = false;
        });
      }
    }
  }

  void _sendCommand() {
    final command = _inputController.text;
    if (command.isNotEmpty && shellSession != null) {
      if (_commandHistory.isEmpty || _commandHistory.last != command) {
        _commandHistory.add(command);
        if (_commandHistory.length > 100) {
          _commandHistory.removeAt(0);
        }
      }
      _historyIndex = -1;
      
      shellSession!.write(Uint8List.fromList(utf8.encode('$command\n')));
      _inputController.clear();
    }
  }

  void _handleKeyEvent(KeyEvent event) {
    if (event is KeyDownEvent) {
      if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
        if (_commandHistory.isNotEmpty) {
          if (_historyIndex == -1) {
            _historyIndex = _commandHistory.length - 1;
          } else if (_historyIndex > 0) {
            _historyIndex--;
          }
          _inputController.text = _commandHistory[_historyIndex];
          _inputController.selection = TextSelection.fromPosition(
            TextPosition(offset: _inputController.text.length),
          );
        }
      } else if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
        if (_historyIndex != -1) {
          if (_historyIndex < _commandHistory.length - 1) {
            _historyIndex++;
            _inputController.text = _commandHistory[_historyIndex];
          } else {
            _historyIndex = -1;
            _inputController.clear();
          }
          _inputController.selection = TextSelection.fromPosition(
            TextPosition(offset: _inputController.text.length),
          );
        }
      } else if (event.logicalKey == LogicalKeyboardKey.tab) {
        final text = _inputController.text;
        if (text.isNotEmpty && shellSession != null) {
          shellSession!.write(Uint8List.fromList([9]));
        }
      } else if (event.logicalKey == LogicalKeyboardKey.controlLeft && 
                 event.logicalKey == LogicalKeyboardKey.keyC) {
        if (shellSession != null) {
          shellSession!.write(Uint8List.fromList([3]));
        }
      }
    }
  }

  Widget _buildOutputLine(String line) {
    if (!line.contains('\x1b[')) {
      return Text(
        line,
        style: const TextStyle(
          color: Colors.white,
          fontFamily: 'monospace',
          fontSize: 13,
          height: 1.2,
        ),
      );
    }
    
    final cleanLine = line.replaceAll(RegExp(r'\x1b\[[0-9;]*m'), '');
    return Text(
      cleanLine,
      style: const TextStyle(
        color: Colors.white,
        fontFamily: 'monospace',
        fontSize: 13,
        height: 1.2,
      ),
    );
  }

  @override
  void dispose() {
    shellSession?.close();
    client?.close();
    _inputController.dispose();
    _scrollController.dispose();
    _inputFocus.dispose();
    super.dispose();
  }

  void _reconnect() {
    _connectSSH(currentHost);
  }

  void _clearTerminal() {
    setState(() {
      _outputLines.clear();
      _currentLine = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    
    return Scaffold(
      backgroundColor: const Color(0xFF0C0C0C),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E1E1E),
        title: Text(
          '${currentHost.username}@${currentHost.hostnameOrIp}',
          style: const TextStyle(color: Colors.white, fontSize: 16),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.clear_all, color: Colors.white70),
            tooltip: "Clear Terminal",
            onPressed: _clearTerminal,
          ),
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white70),
            tooltip: "Reconnect",
            onPressed: _reconnect,
          ),
          // REMOVED: Key file picker - this doesn't belong here
        ],
      ),
      body: connecting
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: Colors.green),
                  SizedBox(height: 16),
                  Text("Connecting...", style: TextStyle(color: Colors.white70)),
                ],
              ),
            )
          : errorMessage != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.error_outline, color: Colors.red, size: 48),
                      const SizedBox(height: 16),
                      Text(
                        errorMessage!,
                        style: const TextStyle(color: Colors.red),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _reconnect,
                        child: const Text("Try Again"),
                      ),
                    ],
                  ),
                )
              : Column(
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        child: ListView.builder(
                          controller: _scrollController,
                          itemCount: _outputLines.length + (_currentLine.isNotEmpty ? 1 : 0),
                          itemBuilder: (context, index) {
                            if (index < _outputLines.length) {
                              return _buildOutputLine(_outputLines[index]);
                            } else {
                              return _buildOutputLine(_currentLine);
                            }
                          },
                        ),
                      ),
                    ),
                    
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(
                        color: Color(0xFF1E1E1E),
                        border: Border(top: BorderSide(color: Colors.grey, width: 0.5)),
                      ),
                      child: KeyboardListener(
                        focusNode: FocusNode(),
                        onKeyEvent: _handleKeyEvent,
                        child: Row(
                          children: [
                            const Text(
                              '\$ ',
                              style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold),
                            ),
                            Expanded(
                              child: TextField(
                                controller: _inputController,
                                focusNode: _inputFocus,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'monospace',
                                  fontSize: 14,
                                ),
                                decoration: const InputDecoration(
                                  border: InputBorder.none,
                                  hintText: 'Enter command...',
                                  hintStyle: TextStyle(color: Colors.grey),
                                  isDense: true,
                                  contentPadding: EdgeInsets.zero,
                                ),
                                onSubmitted: (_) => _sendCommand(),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.send, color: Colors.green, size: 20),
                              onPressed: _sendCommand,
                              tooltip: 'Send (Enter)',
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }
}