
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:dartssh2/dartssh2.dart';
import 'package:xterm/xterm.dart';

import '../models/ssh_host.dart';

class TerminalPage extends StatefulWidget {
  final SSHHost host;
  const TerminalPage({super.key, required this.host});

  @override
  State<TerminalPage> createState() => _TerminalPageState();
}

class _TerminalPageState extends State<TerminalPage> {
  late final Terminal _terminal;
  late final TerminalController _controller;

  SSHClient? _client;
  SSHSession? _session;
  StreamSubscription<List<int>>? _stdoutSub;
  StreamSubscription<List<int>>? _stderrSub;

  bool _connecting = true;
  bool _connected = false;
  String? _error;

  @override
  void initState() {
    super.initState();

    _terminal = Terminal(
      maxLines: 20000,
      platform: Platform.isAndroid
          ? TerminalTargetPlatform.android
          : Platform.isIOS
              ? TerminalTargetPlatform.ios
              : Platform.isMacOS
                  ? TerminalTargetPlatform.macos
                  : Platform.isWindows
                      ? TerminalTargetPlatform.windows
                      : TerminalTargetPlatform.linux,
      onOutput: (data) {
        // Keystrokes from the user → SSH stdin
        _session?.write(utf8.encode(data));
      },
      onResize: (width, height, _pw, _ph) {
        // Notify remote PTY when view resizes
        _session?.resizeTerminal(width, height);
      },
    );

    _controller = TerminalController();

    _connect();
  }

  Future<void> _connect() async {
    setState(() {
      _connecting = true;
      _error = null;
    });

    final h = widget.host;
    try {
      _terminal.write('Connecting to ${h.username}@${h.hostnameOrIp}:${h.port} …\r\n');

      final socket = await SSHSocket.connect(
        h.hostnameOrIp,
        h.port,
        timeout: const Duration(seconds: 12),
      );

      // Build client with password and/or key auth
      List<SSHKeyPair>? keyPairs;
      if ((h.keyFilePath ?? '').isNotEmpty) {
        final keyFile = File(h.keyFilePath!);
        if (!await keyFile.exists()) {
          throw Exception('Private key file not found: ${h.keyFilePath}');
        }
        // If a password is provided, treat it as passphrase for encrypted keys.
        keyPairs = SSHKeyPair.fromPem(
          await keyFile.readAsString(),
          (h.password?.isNotEmpty ?? false) ? h.password : null,
        );
      }

      _client = SSHClient(
        socket,
        username: h.username,
        identities: keyPairs,
        onPasswordRequest: () => h.password ?? '',
      );

      // Open interactive shell with PTY so apps like vim/htop work.
      _session = await _client!.shell(
        pty: SSHPtyConfig(
          width: _terminal.viewWidth > 0 ? _terminal.viewWidth : 80,
          height: _terminal.viewHeight > 0 ? _terminal.viewHeight : 24,
          term: 'xterm-256color',
        ),
      );

      // Pipe SSH output to terminal.
      _stdoutSub = _session!.stdout.listen((data) {
        _terminal.write(const Utf8Decoder().convert(data));
      });
      _stderrSub = _session!.stderr.listen((data) {
        _terminal.write(const Utf8Decoder().convert(data));
      });

      // Kick some shells to render prompt
      _session!.write(const Utf8Encoder().convert('\r'));

      if (mounted) {
        setState(() {
          _connecting = false;
          _connected = true;
        });
      }
      _terminal.write('✓ Connected\r\n');
    } catch (e) {
      _terminal.write('✗ Connection failed: $e\r\n');
      if (mounted) {
        setState(() {
          _connecting = false;
          _connected = false;
          _error = e.toString();
        });
      }
    }
  }

  Future<void> _disconnect() async {
    try {
      await _stdoutSub?.cancel();
      await _stderrSub?.cancel();
    } catch (_) {}
    _stdoutSub = null;
    _stderrSub = null;

    try {
      await _session?.done;
    } catch (_) {}
    _session = null;

    try {
      _client?.close();
      await _client?.done;
    } catch (_) {}
    _client = null;

    if (mounted) setState(() => _connected = false);
  }

  @override
  void dispose() {
    _disconnect();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null && data!.text!.isNotEmpty) {
      _terminal.paste(data.text!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final h = widget.host;

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text('${h.name}  —  ${h.username}@${h.hostnameOrIp}:${h.port}'),
        actions: [
          IconButton(
            tooltip: 'Reconnect',
            onPressed: _connecting
                ? null
                : () async {
                    await _disconnect();
                    _terminal = Terminal(
                      maxLines: 20000,
                      platform: Platform.isAndroid
                          ? TerminalTargetPlatform.android
                          : Platform.isIOS
                              ? TerminalTargetPlatform.ios
                              : Platform.isMacOS
                                  ? TerminalTargetPlatform.macos
                                  : Platform.isWindows
                                      ? TerminalTargetPlatform.windows
                                      : TerminalTargetPlatform.linux,
                      onOutput: (data) => _session?.write(utf8.encode(data)),
                      onResize: (w, h, _pw, _ph) => _session?.resizeTerminal(w, h),
                    );
                    setState(() {});
                    _connect();
                  },
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            tooltip: 'Paste',
            onPressed: _pasteFromClipboard,
            icon: const Icon(Icons.content_paste),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Focus(
              autofocus: true,
              child: TerminalView(
                _terminal,
                controller: _controller,
                autofocus: true,
                autoResize: true,
                theme: TerminalThemes.whiteOnBlack,
                cursorType: TerminalCursorType.block,
                onSecondaryTapDown: (details, offset) async {
                  final choice = await showMenu<String>(
                    context: context,
                    position: RelativeRect.fromLTRB(
                      details.globalPosition.dx,
                      details.globalPosition.dy,
                      0,
                      0,
                    ),
                    items: const [
                      PopupMenuItem(value: 'paste', child: Text('Paste')),
                      PopupMenuItem(value: 'clear', child: Text('Clear')),
                    ],
                  );
                  switch (choice) {
                    case 'paste':
                      _pasteFromClipboard();
                      break;
                    case 'clear':
                      _terminal.eraseDisplay();
                      break;
                  }
                },
              ),
            ),
          ),
          _StatusBar(connected: _connected, connecting: _connecting, error: _error),
        ],
      ),
    );
  }
}

class _StatusBar extends StatelessWidget {
  final bool connected;
  final bool connecting;
  final String? error;
  const _StatusBar({required this.connected, required this.connecting, this.error});

  @override
  Widget build(BuildContext context) {
    final text = connecting
        ? 'Connecting…'
        : (connected ? 'Connected' : (error != null ? 'Disconnected — $error' : 'Disconnected'));

    return Container(
      height: 32,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      alignment: Alignment.centerLeft,
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: Colors.black26)),
      ),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelMedium?.copyWith(color: Colors.white70),
      ),
    );
  }
}
